// V75 tile-major BL8 input prefetch and banked portrait output.
// Fixed 720x480 canonical YUV420/HUD -> native portrait RGB565 presentation.
// Word addresses are x16, canonical samples are packed low-byte first.
// One memory operation outstanding: aligned BL8 read or complete BL8 write.
// A write reply means all enabled words are visible and recovery is drained.
`timescale 1ns/1ps
module cu75_painter_burst (
    input logic clk,rst,abort_i,
    input logic start_valid,output logic start_ready,
    input logic [63:0] generation,
    input logic [31:0] frame_id,
    input logic [23:0] y_base,u_base,v_base,hud_base,rgb_base,
    output logic aux_req_valid,input logic aux_req_ready,
    output logic aux_req_write,
    output logic [23:0] aux_req_addr,
    output logic [15:0] aux_req_data,
    output logic aux_req_burst,aux_req_read_burst,
    output logic [127:0] aux_req_burst_data,
    output logic [15:0] aux_req_byte_enable,
    input logic aux_rsp_valid,output logic aux_rsp_ready,
    /* verilator lint_off UNUSEDSIGNAL */
    input logic [15:0] aux_rsp_data,
    /* verilator lint_on UNUSEDSIGNAL */
    input logic [127:0] aux_rsp_burst_data,input logic aux_rsp_error,
    output logic result_valid,input logic result_ready,
    output logic [63:0] result_generation,
    output logic [31:0] result_frame_id,
    output logic busy,done,aborted,error,
    output logic [7:0] error_code,
    output logic [31:0] memory_reads,memory_read_words,memory_writes,memory_write_words,painted_pixels,cycle_count
);
    typedef enum logic [4:0] {IDLE,TOP_BAR,ROW_BEGIN,LOAD_REQ,LOAD_RSP,
        PIXEL_FETCH,PIXEL_FETCH_RIGHT,PIXEL_COMPOSE,HUD_FETCH,WRITE_REQ,WRITE_RSP,
        BOTTOM_BAR,RESULT,DRAIN,STRIP_DRAIN,UNPACK} state_t;
    state_t state,after_load,after_write;
    logic [23:0] yb,ub,vb,hb,rb,load_base,write_addr;
    logic [127:0] write_data;
    logic [1:0] load_kind;
    logic [5:0] load_quad;
    logic [6:0] load_tx;
    logic [1:0] load_chunk;
    logic [2:0] unpack_index;
    logic [127:0] read_data;
    logic [5:0] quad_tag [0:1];
    logic [1:0] quad_valid;
    logic [5:0] stripe_quad;
    logic [2:0] cache_bank;
    logic [8:0] cache_column;
    logic [15:0] cache_word;
    logic [9:0] x,y;
    logic [14:0] bar_index;
    logic [2:0] row_stage;
    logic [15:0] yw0 [0:359];
logic [15:0] yw1 [0:359];
logic [15:0] yw2 [0:359];
logic [15:0] yw3 [0:359];
logic [15:0] yw4 [0:359];
logic [15:0] yw5 [0:359];
logic [15:0] yw6 [0:359];
logic [15:0] yw7 [0:359];
logic [15:0] cb0 [0:179];
logic [15:0] cb1 [0:179];
logic [15:0] cb2 [0:179];
logic [15:0] cb3 [0:179];
logic [15:0] cb4 [0:179];
logic [15:0] cb5 [0:179];
logic [15:0] cb6 [0:179];
logic [15:0] cb7 [0:179];
logic [15:0] cr0 [0:179];
logic [15:0] cr1 [0:179];
logic [15:0] cr2 [0:179];
logic [15:0] cr3 [0:179];
logic [15:0] cr4 [0:179];
logic [15:0] cr5 [0:179];
logic [15:0] cr6 [0:179];
logic [15:0] cr7 [0:179];
    logic [7:0] chroma_word_address;
    logic [15:0] yw_word0;
    logic [15:0] yw_word1;
    logic [15:0] yw_word2;
    logic [15:0] yw_word3;
    logic [15:0] yw_word4;
    logic [15:0] yw_word5;
    logic [15:0] yw_word6;
    logic [15:0] yw_word7;
    logic [15:0] cb_word0;
    logic [15:0] cb_word1;
    logic [15:0] cb_word2;
    logic [15:0] cb_word3;
    logic [15:0] cb_word4;
    logic [15:0] cb_word5;
    logic [15:0] cb_word6;
    logic [15:0] cb_word7;
    logic [15:0] cr_word0;
    logic [15:0] cr_word1;
    logic [15:0] cr_word2;
    logic [15:0] cr_word3;
    logic [15:0] cr_word4;
    logic [15:0] cr_word5;
    logic [15:0] cr_word6;
    logic [15:0] cr_word7;
    logic [15:0] hud_words [0:7];
    // Eight coded rows are transposed into short contiguous portrait runs.
    // One 720-word row-lane RAM per bank; one selected write and one read.
    // The eight synchronous read values are gathered into write_data below.
    logic [15:0] strip0 [0:719];
    logic [15:0] strip1 [0:719];
    logic [15:0] strip2 [0:719];
    logic [15:0] strip3 [0:719];
    logic [15:0] strip4 [0:719];
    logic [15:0] strip5 [0:719];
    logic [15:0] strip6 [0:719];
    logic [15:0] strip7 [0:719];
    logic [9:0] drain_x;
    logic [8:0] strip_y;
    logic [23:0] hud_cache_tag;
    logic hud_cache_valid;
    logic pending;
    logic [7:0] ys,ct0,ct1,cb0s,cb1s,rt0,rt1,rb0s,rb1s;
    logic [8:0] cx,cx1;
    logic [7:0] cy;
    logic [2:0] top_bank,bottom_bank;
    logic hud_hit;
    logic [14:0] hud_index;
    logic [23:0] hud_address;
    logic signed [31:0] cb_top,cb_bottom,cr_top,cr_bottom,cb,cr,rr,gg,bb;
    logic [15:0] converted;

    function automatic logic ranges_overlap(input logic [23:0] a,input logic [24:0] an,
                                             input logic [23:0] b,input logic [24:0] bn);
        ranges_overlap=({1'b0,a}<{1'b0,b}+bn)&&({1'b0,b}<{1'b0,a}+an);
    endfunction
    function automatic [7:0] clip(input logic signed [31:0] n);
        if(n<0)clip=0;else if(n>255)clip=255;else clip=n[7:0];
    endfunction
    always_comb begin
        cx=9'(x>>1);cx1=cx==359?cx:cx+1;cy=8'(y>>1);
        chroma_word_address=state==PIXEL_FETCH?cx[8:1]:cx1[8:1];
        top_bank=cy[2:0];bottom_bank=cy==239?cy[2:0]:cy[2:0]+3'd1;
        stripe_quad=6'(y>>3);
        cache_bank=load_kind==0?{load_chunk,1'b0}+3'(unpack_index>>2):{load_quad[0],2'b00}+{1'b0,load_chunk[0],1'b0}+3'(unpack_index>>2);
        cache_column=9'(load_tx)*9'd4+9'(unpack_index[1:0]);
        cache_word=read_data[16*int'(unpack_index)+:16];
        hud_hit=0;hud_index=0;
        if(x>=22&&x<182&&y>=54&&y<78)begin hud_hit=1;hud_index=15'((int'(y)-54)*160+int'(x)-22);end
        else if(x>=22&&x<182&&y>=82&&y<106)begin hud_hit=1;hud_index=15'(3840+(int'(y)-82)*160+int'(x)-22);end
        else if(x>=168&&x<488&&y>=360&&y<384)begin hud_hit=1;hud_index=15'(7680+(int'(y)-360)*320+int'(x)-168);end
        else if(x>=168&&x<408&&y>=390&&y<414)begin hud_hit=1;hud_index=15'(15360+(int'(y)-390)*240+int'(x)-168);end
        hud_address=hb+24'(hud_index);
        case(top_bank)
            3'd0:begin ct1=cb_word0[8*int'(cx1[0])+:8];rt1=cr_word0[8*int'(cx1[0])+:8];end
            3'd1:begin ct1=cb_word1[8*int'(cx1[0])+:8];rt1=cr_word1[8*int'(cx1[0])+:8];end
            3'd2:begin ct1=cb_word2[8*int'(cx1[0])+:8];rt1=cr_word2[8*int'(cx1[0])+:8];end
            3'd3:begin ct1=cb_word3[8*int'(cx1[0])+:8];rt1=cr_word3[8*int'(cx1[0])+:8];end
            3'd4:begin ct1=cb_word4[8*int'(cx1[0])+:8];rt1=cr_word4[8*int'(cx1[0])+:8];end
            3'd5:begin ct1=cb_word5[8*int'(cx1[0])+:8];rt1=cr_word5[8*int'(cx1[0])+:8];end
            3'd6:begin ct1=cb_word6[8*int'(cx1[0])+:8];rt1=cr_word6[8*int'(cx1[0])+:8];end
            3'd7:begin ct1=cb_word7[8*int'(cx1[0])+:8];rt1=cr_word7[8*int'(cx1[0])+:8];end
        endcase
        case(bottom_bank)
            3'd0:begin cb1s=cb_word0[8*int'(cx1[0])+:8];rb1s=cr_word0[8*int'(cx1[0])+:8];end
            3'd1:begin cb1s=cb_word1[8*int'(cx1[0])+:8];rb1s=cr_word1[8*int'(cx1[0])+:8];end
            3'd2:begin cb1s=cb_word2[8*int'(cx1[0])+:8];rb1s=cr_word2[8*int'(cx1[0])+:8];end
            3'd3:begin cb1s=cb_word3[8*int'(cx1[0])+:8];rb1s=cr_word3[8*int'(cx1[0])+:8];end
            3'd4:begin cb1s=cb_word4[8*int'(cx1[0])+:8];rb1s=cr_word4[8*int'(cx1[0])+:8];end
            3'd5:begin cb1s=cb_word5[8*int'(cx1[0])+:8];rb1s=cr_word5[8*int'(cx1[0])+:8];end
            3'd6:begin cb1s=cb_word6[8*int'(cx1[0])+:8];rb1s=cr_word6[8*int'(cx1[0])+:8];end
            3'd7:begin cb1s=cb_word7[8*int'(cx1[0])+:8];rb1s=cr_word7[8*int'(cx1[0])+:8];end
        endcase
        cb_top=x[0]?((32'(ct0)+32'(ct1)+1)>>1):32'(ct0);
        cb_bottom=x[0]?((32'(cb0s)+32'(cb1s)+1)>>1):32'(cb0s);
        cr_top=x[0]?((32'(rt0)+32'(rt1)+1)>>1):32'(rt0);
        cr_bottom=x[0]?((32'(rb0s)+32'(rb1s)+1)>>1):32'(rb0s);
        cb=(y[0]?((cb_top+cb_bottom+1)>>>1):cb_top)-128;
        cr=(y[0]?((cr_top+cr_bottom+1)>>>1):cr_top)-128;
        rr=$signed({24'd0,ys})+((359*cr+128)>>>8);
        gg=$signed({24'd0,ys})-((88*cb+183*cr+128)>>>8);
        bb=$signed({24'd0,ys})+((454*cb+128)>>>8);
        converted={5'(clip(rr)>>3),6'(clip(gg)>>2),5'(clip(bb)>>3)};
        start_ready=state==IDLE&&!rst&&!abort_i;
        busy=state!=IDLE;
        result_valid=state==RESULT&&!rst&&!abort_i;
        aux_req_valid=(state==LOAD_REQ||state==WRITE_REQ)&&!rst&&!abort_i;
        aux_req_write=state==WRITE_REQ;
        aux_req_addr=write_addr;
        if(!aux_req_write)begin
            if(load_kind==3)aux_req_addr=load_base;
            else if(load_kind==0)aux_req_addr=load_base+24'(((int'(y)>>3)*90+int'(load_tx))*32+int'(load_chunk)*8);
            else aux_req_addr=load_base+24'(((int'(load_quad)>>1)*45+int'(load_tx))*32+int'(load_quad[0])*16+int'(load_chunk)*8);
        end
        aux_req_data=write_data[15:0];
        aux_req_burst=aux_req_write;
        aux_req_read_burst=state==LOAD_REQ;
        aux_req_burst_data=write_data;
        aux_req_byte_enable=aux_req_write?16'hffff:16'd0;
        aux_rsp_ready=pending&&!rst;
    end

    task automatic load(input logic [1:0] kind,input logic [5:0] quad,
                         input logic [23:0] address,input state_t return_state);
        begin load_kind<=kind;load_quad<=quad;load_base<=address;
            load_tx<=0;load_chunk<=0;after_load<=return_state;state<=LOAD_REQ;end
    endtask
    task automatic write_burst(input logic [23:0] address,input logic [127:0] data,
                              input state_t return_state);
        begin write_addr<=address;write_data<=data;after_write<=return_state;state<=WRITE_REQ;end
    endtask
    task automatic emit_pixel(input logic [15:0] data);
        begin
            case(y[2:0])
                3'd0:strip0[x]<=data;
                3'd1:strip1[x]<=data;
                3'd2:strip2[x]<=data;
                3'd3:strip3[x]<=data;
                3'd4:strip4[x]<=data;
                3'd5:strip5[x]<=data;
                3'd6:strip6[x]<=data;
                3'd7:strip7[x]<=data;
            endcase
            painted_pixels<=painted_pixels+1;
            if(x==719)begin
                x<=0;y<=y+1;
                if(y[2:0]==7)begin
                    strip_y<=y[8:0]-9'd7;drain_x<=0;state<=STRIP_DRAIN;
                end else state<=ROW_BEGIN;
            end else begin x<=x+1;state<=PIXEL_FETCH;end
        end
    endtask
    // Cache memory outputs are clocked full words. Byte-lane selection happens
    // only after these registers; unpack writes and pixel reads are disjoint.
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd0)yw0[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word0<=yw0[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd1)yw1[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word1<=yw1[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd2)yw2[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word2<=yw2[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd3)yw3[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word3<=yw3[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd4)yw4[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word4<=yw4[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd5)yw5[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word5<=yw5[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd6)yw6[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word6<=yw6[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd0&&cache_bank==3'd7)yw7[cache_column]<=cache_word;
        if(!rst&&!abort_i&&state==PIXEL_FETCH)yw_word7<=yw7[x[9:1]];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd0)cb0[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word0<=cb0[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd1)cb1[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word1<=cb1[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd2)cb2[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word2<=cb2[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd3)cb3[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word3<=cb3[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd4)cb4[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word4<=cb4[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd5)cb5[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word5<=cb5[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd6)cb6[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word6<=cb6[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd1&&cache_bank==3'd7)cb7[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cb_word7<=cb7[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd0)cr0[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word0<=cr0[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd1)cr1[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word1<=cr1[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd2)cr2[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word2<=cr2[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd3)cr3[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word3<=cr3[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd4)cr4[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word4<=cr4[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd5)cr5[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word5<=cr5[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd6)cr6[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word6<=cr6[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(!rst&&!abort_i&&state==UNPACK&&load_kind==2'd2&&cache_bank==3'd7)cr7[cache_column[7:0]]<=cache_word;
        if(!rst&&!abort_i&&(state==PIXEL_FETCH||state==PIXEL_FETCH_RIGHT))cr_word7<=cr7[chroma_word_address];
    end
    always_ff @(posedge clk)begin
        if(rst)begin
            state<=IDLE;after_load<=IDLE;after_write<=IDLE;pending<=0;drain_x<=0;strip_y<=0;
            yb<=0;ub<=0;vb<=0;hb<=0;rb<=0;load_base<=0;write_addr<=0;write_data<=0;
            load_kind<=0;load_quad<=0;load_tx<=0;load_chunk<=0;unpack_index<=0;read_data<=0;quad_valid<=0;quad_tag[0]<=0;quad_tag[1]<=0;x<=0;y<=0;bar_index<=0;row_stage<=0;
            hud_cache_tag<=0;hud_cache_valid<=0;ys<=0;ct0<=0;cb0s<=0;
            rt0<=0;rb0s<=0;result_generation<=0;result_frame_id<=0;
            done<=0;aborted<=0;error<=0;error_code<=0;memory_reads<=0;memory_read_words<=0;memory_writes<=0;memory_write_words<=0;painted_pixels<=0;cycle_count<=0;
        end else begin
            done<=0;aborted<=0;
            if(busy)cycle_count<=cycle_count+1;
            if(aux_req_valid&&aux_req_ready)begin
                pending<=1;
                if(aux_req_write)begin memory_writes<=memory_writes+1;memory_write_words<=memory_write_words+8;end
                else begin memory_reads<=memory_reads+1;memory_read_words<=memory_read_words+8;end
            end
            if(aux_rsp_valid&&aux_rsp_ready)pending<=0;
            if(abort_i&&state!=IDLE&&state!=DRAIN)state<=DRAIN;
            else if(aux_rsp_valid&&aux_rsp_ready&&aux_rsp_error&&state!=DRAIN)begin
                state<=DRAIN;error<=1;error_code<=8'd2;
            end else case(state)
                IDLE:if(start_valid&&start_ready)begin
                    result_generation<=generation;result_frame_id<=frame_id;
                    memory_reads<=0;memory_read_words<=0;memory_writes<=0;memory_write_words<=0;painted_pixels<=0;cycle_count<=0;
                    error<=0;error_code<=0;hud_cache_valid<=0;quad_valid<=0;x<=0;y<=0;bar_index<=0;row_stage<=0;
                    yb<=y_base;ub<=u_base;vb<=v_base;hb<=hud_base;rb<=rgb_base;
                    if(generation==0||frame_id==32'hffffffff||rgb_base[2:0]!=0||
                       {1'b0,y_base}+25'd172800>25'h1000000||
                       {1'b0,u_base}+25'd43200>25'h1000000||
                       {1'b0,v_base}+25'd43200>25'h1000000||
                       {1'b0,hud_base}+25'd21120>25'h1000000||
                       {1'b0,rgb_base}+25'd384000>25'h1000000||
                       ranges_overlap(y_base,25'd172800,u_base,25'd43200)||
                       ranges_overlap(y_base,25'd172800,v_base,25'd43200)||
                       ranges_overlap(y_base,25'd172800,hud_base,25'd21120)||
                       ranges_overlap(y_base,25'd172800,rgb_base,25'd384000)||
                       ranges_overlap(u_base,25'd43200,v_base,25'd43200)||
                       ranges_overlap(u_base,25'd43200,hud_base,25'd21120)||
                       ranges_overlap(u_base,25'd43200,rgb_base,25'd384000)||
                       ranges_overlap(v_base,25'd43200,hud_base,25'd21120)||
                       ranges_overlap(v_base,25'd43200,rgb_base,25'd384000)||
                       ranges_overlap(hud_base,25'd21120,rgb_base,25'd384000))begin
                        error<=1;error_code<=1;state<=DRAIN;
                    end else state<=TOP_BAR;
                end
                TOP_BAR:begin
                    write_burst(rb+24'(bar_index),128'd0,TOP_BAR);
                    if(bar_index==19192)begin after_write<=ROW_BEGIN;bar_index<=0;end
                    else bar_index<=bar_index+8;
                end
                ROW_BEGIN:case(row_stage)
                    0:begin row_stage<=1;if(y[2:0]==0)load(0,0,yb,ROW_BEGIN);end
                    1:begin row_stage<=2;if(y[2:0]==0&&(!quad_valid[stripe_quad[0]]||quad_tag[stripe_quad[0]]!=stripe_quad))load(1,stripe_quad,ub,ROW_BEGIN);end
                    2:begin row_stage<=3;if(y[2:0]==0&&(!quad_valid[stripe_quad[0]]||quad_tag[stripe_quad[0]]!=stripe_quad))load(2,stripe_quad,vb,ROW_BEGIN);end
                    3:begin row_stage<=4;if(y[2:0]==0&&stripe_quad<59&&(!quad_valid[!stripe_quad[0]]||quad_tag[!stripe_quad[0]]!=stripe_quad+1))load(1,stripe_quad+1,ub,ROW_BEGIN);end
                    4:begin row_stage<=5;if(y[2:0]==0&&stripe_quad<59&&(!quad_valid[!stripe_quad[0]]||quad_tag[!stripe_quad[0]]!=stripe_quad+1))load(2,stripe_quad+1,vb,ROW_BEGIN);end
                    default:begin row_stage<=0;state<=PIXEL_FETCH;end
                endcase
                LOAD_REQ:if(aux_req_valid&&aux_req_ready)state<=LOAD_RSP;
                LOAD_RSP:if(aux_rsp_valid&&aux_rsp_ready)begin
                    read_data<=aux_rsp_burst_data;unpack_index<=0;state<=UNPACK;
                end
                UNPACK:begin
                    if(load_kind==3)hud_words[unpack_index]<=cache_word;
                    if(unpack_index!=7)unpack_index<=unpack_index+1;
                    else if(load_kind==3)begin
                        hud_cache_tag<=load_base;hud_cache_valid<=1;state<=after_load;
                    end else if((load_kind==0&&load_chunk==3)||(load_kind!=0&&load_chunk==1))begin
                        load_chunk<=0;
                        if((load_kind==0&&load_tx==89)||(load_kind!=0&&load_tx==44))begin
                            if(load_kind==2)begin quad_tag[load_quad[0]]<=load_quad;quad_valid[load_quad[0]]<=1;end
                            state<=after_load;
                        end else begin load_tx<=load_tx+1;state<=LOAD_REQ;end
                    end else begin load_chunk<=load_chunk+1;state<=LOAD_REQ;end
                end
                PIXEL_FETCH:state<=PIXEL_FETCH_RIGHT;
                PIXEL_FETCH_RIGHT:begin
                    case(y[2:0])
                        3'd0:ys<=yw_word0[8*int'(x[0])+:8];
                        3'd1:ys<=yw_word1[8*int'(x[0])+:8];
                        3'd2:ys<=yw_word2[8*int'(x[0])+:8];
                        3'd3:ys<=yw_word3[8*int'(x[0])+:8];
                        3'd4:ys<=yw_word4[8*int'(x[0])+:8];
                        3'd5:ys<=yw_word5[8*int'(x[0])+:8];
                        3'd6:ys<=yw_word6[8*int'(x[0])+:8];
                        3'd7:ys<=yw_word7[8*int'(x[0])+:8];
                    endcase
                    case(top_bank)
                        3'd0:begin ct0<=cb_word0[8*int'(cx[0])+:8];rt0<=cr_word0[8*int'(cx[0])+:8];end
                        3'd1:begin ct0<=cb_word1[8*int'(cx[0])+:8];rt0<=cr_word1[8*int'(cx[0])+:8];end
                        3'd2:begin ct0<=cb_word2[8*int'(cx[0])+:8];rt0<=cr_word2[8*int'(cx[0])+:8];end
                        3'd3:begin ct0<=cb_word3[8*int'(cx[0])+:8];rt0<=cr_word3[8*int'(cx[0])+:8];end
                        3'd4:begin ct0<=cb_word4[8*int'(cx[0])+:8];rt0<=cr_word4[8*int'(cx[0])+:8];end
                        3'd5:begin ct0<=cb_word5[8*int'(cx[0])+:8];rt0<=cr_word5[8*int'(cx[0])+:8];end
                        3'd6:begin ct0<=cb_word6[8*int'(cx[0])+:8];rt0<=cr_word6[8*int'(cx[0])+:8];end
                        3'd7:begin ct0<=cb_word7[8*int'(cx[0])+:8];rt0<=cr_word7[8*int'(cx[0])+:8];end
                    endcase
                    case(bottom_bank)
                        3'd0:begin cb0s<=cb_word0[8*int'(cx[0])+:8];rb0s<=cr_word0[8*int'(cx[0])+:8];end
                        3'd1:begin cb0s<=cb_word1[8*int'(cx[0])+:8];rb0s<=cr_word1[8*int'(cx[0])+:8];end
                        3'd2:begin cb0s<=cb_word2[8*int'(cx[0])+:8];rb0s<=cr_word2[8*int'(cx[0])+:8];end
                        3'd3:begin cb0s<=cb_word3[8*int'(cx[0])+:8];rb0s<=cr_word3[8*int'(cx[0])+:8];end
                        3'd4:begin cb0s<=cb_word4[8*int'(cx[0])+:8];rb0s<=cr_word4[8*int'(cx[0])+:8];end
                        3'd5:begin cb0s<=cb_word5[8*int'(cx[0])+:8];rb0s<=cr_word5[8*int'(cx[0])+:8];end
                        3'd6:begin cb0s<=cb_word6[8*int'(cx[0])+:8];rb0s<=cr_word6[8*int'(cx[0])+:8];end
                        3'd7:begin cb0s<=cb_word7[8*int'(cx[0])+:8];rb0s<=cr_word7[8*int'(cx[0])+:8];end
                    endcase
                    state<=PIXEL_COMPOSE;
                end
                PIXEL_COMPOSE:begin
                    if(hud_hit)state<=HUD_FETCH;
                    else emit_pixel(converted);
                end
                HUD_FETCH:begin
                    if(hud_cache_valid&&hud_cache_tag=={hud_address[23:3],3'b000})
                        emit_pixel(hud_words[hud_address[2:0]]);
                    else load(3,0,{hud_address[23:3],3'b000},HUD_FETCH);
                end
                STRIP_DRAIN:begin
                    write_burst(rb+24'((int'(drain_x)+40)*480+int'(strip_y)),
                        {strip7[drain_x],strip6[drain_x],
                         strip5[drain_x],strip4[drain_x],
                         strip3[drain_x],strip2[drain_x],
                         strip1[drain_x],strip0[drain_x]},STRIP_DRAIN);
                    if(drain_x==719)begin
                        bar_index<=0;
                        after_write<=strip_y==472?BOTTOM_BAR:ROW_BEGIN;
                    end else drain_x<=drain_x+1;
                end
                WRITE_REQ:if(aux_req_valid&&aux_req_ready)state<=WRITE_RSP;
                WRITE_RSP:if(aux_rsp_valid&&aux_rsp_ready)state<=after_write;
                BOTTOM_BAR:begin
                    write_burst(rb+24'd364800+24'(bar_index),128'd0,BOTTOM_BAR);
                    if(bar_index==19192)after_write<=RESULT;
                    else bar_index<=bar_index+8;
                end
                RESULT:if(result_valid&&result_ready)begin done<=1;state<=IDLE;end
                DRAIN:if(!pending)begin aborted<=1;state<=IDLE;end
                default:begin state<=DRAIN;error<=1;error_code<=3;end
            endcase
        end
    end
endmodule
