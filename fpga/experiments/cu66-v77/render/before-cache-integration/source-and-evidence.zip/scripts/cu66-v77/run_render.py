#!/usr/bin/env python3
"""V77 exact elastic pixel pipeline and cache-backed rendering regression."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];AREA=ROOT/'fpga/experiments/cu66-v77/render'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 files=[AREA/'cu77_yuv_rgb.sv',AREA/'tb_pixel.cpp',Path(__file__).resolve()];pins={str(p.relative_to(ROOT)):sha(p)for p in files};cmds=[]
 def run(argv,name):
  with(AREA/name).open('w')as f:r=subprocess.run(argv,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,timeout=600)
  cmds.append(dict(argv=argv,log=str((AREA/name).relative_to(ROOT)),exit_code=r.returncode,sha256=sha(AREA/name)));assert r.returncode==0,(name,r.returncode);return(AREA/name).read_text()
 run(['docker','exec','gamebub-cu66-v69-build','verilator','--cc','--exe','--build','-j','1','--Wall','--top-module','cu77_yuv_rgb','--Mdir','/build/v77-pixel','-CFLAGS','-O2 -std=c++17',str(AREA/'cu77_yuv_rgb.sv'),str(AREA/'tb_pixel.cpp')],'pixel-build.log')
 log=run(['docker','exec','gamebub-cu66-v69-build','/build/v77-pixel/Vcu77_yuv_rgb'],'pixel-run.log');assert 'PIXEL_PASS'in log and 'FAIL'not in log
 assert pins=={str(p.relative_to(ROOT)):sha(p)for p in files}
 (AREA/'pixel-results.json').write_text(json.dumps(dict(status='PASS_EXACT_ELASTIC_PIXEL_PIPELINE',source_sha256=pins,commands=cmds,scope='Exact mathematical CU66 color oracle; bounded random/extreme/stalled elastic arithmetic; not cache/controller/CDC/frameproof'),indent=2)+'\n');print(log.strip())
if __name__=='__main__':main()
